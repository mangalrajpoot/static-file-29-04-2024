function demo()
{
    let a=5;
    let b=10;
    alert(a+b);
}